// debugOverlay.js - minimal debug overlay to capture logs
export function initDebugOverlay(){
  // Simple console-based debug overlay for the skeleton
  console.log('[DebugOverlay] initialized (skeleton)');
  // In full refactor move UI debug code here (DOM elements, buttons, clear/copy)
}
