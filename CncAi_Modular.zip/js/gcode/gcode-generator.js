// gcode-generator.js - skeleton of gcode generation functions
export function generateRasterGcode(settings, imageData){
  console.log('generateRasterGcode - skeleton', settings);
  return '; raster gcode (skeleton)\n';
}
export function generateContourGcode(settings, contours){
  console.log('generateContourGcode - skeleton', settings);
  return '; contour gcode (skeleton)\n';
}
