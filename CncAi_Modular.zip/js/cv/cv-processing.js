// cv-processing.js - skeleton for OpenCV functions
export async function initCV(){
  return new Promise((resolve, reject) => {
    // Wait for cv to be ready (opencv.js from CDN sets cv.onRuntimeInitialized)
    if(window.cv && window.cv.onRuntimeInitialized){
      // if ready immediately
      if(window.cv['ready']) return resolve();
      window.cv['ready'] = true;
      console.log('[cv] already present');
      return resolve();
    }
    // set timeout fallback
    let attempts = 0;
    const interval = setInterval(()=>{
      attempts++;
      if(window.cv && window.cv.onRuntimeInitialized){
        clearInterval(interval);
        window.cv['ready'] = true;
        console.log('[cv] runtime initialized (detected after interval)');
        return resolve();
      }
      if(attempts>30){
        clearInterval(interval);
        console.warn('[cv] not found after waiting (skeleton mode)');
        return reject(new Error('OpenCV not found'));
      }
    }, 200);
  });
}
export function renderHeatmap(){ console.log('renderHeatmap - skeleton'); }
export function detectEdges(){ console.log('detectEdges - skeleton'); }
