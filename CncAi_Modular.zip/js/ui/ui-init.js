// ui-init.js - UI bindings skeleton
import { taskManager } from '../core/taskManager.js';
export function initUI(){
  console.log('UI skeleton init');
  // Example: wire a sample button if present
  const sampleBtn = document.getElementById('btnGen');
  if(sampleBtn){
    sampleBtn.addEventListener('click', ()=>{
      taskManager.addTask(async ()=>{ console.log('Sample generate task executed'); }, 'sample-generate');
    });
  }
}
