// utils.js - misc helpers
export function sleep(ms){ return new Promise(r=>setTimeout(r, ms)); }
export function downloadText(filename, text){
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([text], {type:'text/plain'}));
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
}
