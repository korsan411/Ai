// validators.js - input validation helpers
export function clamp(v, a, b){ return Math.max(a, Math.min(b, v)); }
export function isNumber(v){ return typeof v === 'number' && !isNaN(v); }
