// debugOverlay.js - minimal debug overlay to capture logs
export function initDebugOverlay(){
  console.log('[DebugOverlay] initialized (skeleton)');
}
